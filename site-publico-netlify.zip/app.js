// Cadastre o título aqui, o conteúdo em ebook_content.py / ebook_extensions.py e gere com python generate_ebooks.py.
const subjects = [
  "Cálculo",
  "Física",
  "Resistência dos Materiais",
  "Mecânica dos Solos",
  "Materiais de Construção",
  "Estruturas de Concreto",
  "Estruturas de Aço",
  "Hidráulica",
  "Saneamento",
  "Topografia",
  "Geotecnia",
  "Construção Civil",
  "Planejamento e Orçamento de Obras",
  "Segurança do Trabalho",
  "Outras matérias"
];

const books = [
  {
    id: "calculo-estrutural-fundamentos",
    title: "Fundamentos de Cálculo para Engenharia",
    subject: "Cálculo",
    author: "Biblioteca Engenharia Civil",
    level: "Básico",
    description: "Funções, limites, derivadas e integrais explicados com aplicações e exercícios resolvidos.",
    contents: ["Modelagem com funções", "Limites e continuidade", "Derivadas e taxas de variação", "Integrais e área acumulada", "Funções, composição e aproximação numérica", "Várias variáveis e sensibilidade", "Equações diferenciais e integração aproximada", "Estratégia de resolução e controle de erros"],
    availability: "ebooks/calculo-estrutural-fundamentos.pdf",
    coverImage: "https://images.unsplash.com/photo-1635372722656-389f87a941b7?auto=format&fit=crop&w=800&q=85",
    color: "#284d65",
    pattern: "structure"
  },
  {
    id: "resistencia-materiais-introducao",
    title: "Resistência dos Materiais: primeiros conceitos",
    subject: "Resistência dos Materiais",
    author: "Biblioteca Engenharia Civil",
    level: "Intermediário",
    description: "Guia introdutório de esforços, tensões, deformações e análise elástica com exemplos numéricos.",
    contents: ["Do modelo estrutural aos esforços", "Tensão e deformação axial", "Flexão e cisalhamento", "Deformações e estabilidade", "Torção e propriedades geométricas", "Cortante em vigas e deformadas", "Estados combinados e estabilidade", "Caso de viga e lista de verificação"],
    availability: "ebooks/resistencia-materiais-introducao.pdf",
    coverImage: "https://images.unsplash.com/photo-1493476523860-a6de6ce1b0c3?auto=format&fit=crop&w=800&q=85",
    color: "#465346",
    pattern: "beam"
  },
  {
    id: "solos-investigacao",
    title: "Mecânica dos Solos e Investigação Geotécnica",
    subject: "Mecânica dos Solos",
    author: "Biblioteca Engenharia Civil",
    level: "Intermediário",
    description: "Estude relações entre fases, classificação, tensões efetivas e investigação geotécnica.",
    contents: ["O solo como sistema de fases", "Identificação e classificação", "Tensões, água e resistência", "Investigação e relatório geotécnico", "Compactação, permeabilidade e fluxo", "Adensamento e recalque", "Resistência ao cisalhamento e empuxos", "Campanha e escolha de fundação"],
    availability: "ebooks/solos-investigacao.pdf",
    coverImage: "https://images.unsplash.com/photo-1492496913980-501348b61469?auto=format&fit=crop&w=800&q=85",
    color: "#725b44",
    pattern: "soil"
  },
  {
    id: "concreto-tecnologia",
    title: "Materiais de Construção: o concreto",
    subject: "Materiais de Construção",
    author: "Biblioteca Engenharia Civil",
    level: "Básico",
    description: "Conheça os materiais, o concreto fresco e endurecido, a cura e o controle tecnológico.",
    contents: ["Constituintes e proporções", "Concreto fresco", "Endurecimento, cura e durabilidade", "Controle tecnológico e rastreabilidade", "Cimento, agregados e água", "Dosagem, mistura e ensaios", "Aço, cerâmicos, madeira e outros materiais", "Durabilidade, patologias e registro"],
    availability: "ebooks/concreto-tecnologia.pdf",
    coverImage: "https://images.unsplash.com/photo-1579492450119-80542d516179?auto=format&fit=crop&w=800&q=85",
    color: "#40566b",
    pattern: "grid"
  },
  {
    id: "hidraulica-canais",
    title: "Hidráulica Aplicada a Canais",
    subject: "Hidráulica",
    author: "Biblioteca Engenharia Civil",
    level: "Avançado",
    description: "Revise continuidade, energia, regime de escoamento e a aplicação didática da fórmula de Manning.",
    contents: ["Grandezas e conservação", "Geometria e energia", "Manning em escoamento uniforme", "Aplicação e verificação", "Profundidade crítica e ressalto", "Escoamento variado e estruturas", "Reservação, bombas e redes", "Chuva de projeto e drenagem"],
    availability: "ebooks/hidraulica-canais.pdf",
    coverImage: "https://images.unsplash.com/photo-1587020190382-d7112391d8cd?auto=format&fit=crop&w=800&q=85",
    color: "#325a61",
    pattern: "water"
  },
  {
    id: "planejamento-obras",
    title: "Planejamento e Orçamento de Obras",
    subject: "Planejamento e Orçamento de Obras",
    author: "Biblioteca Engenharia Civil",
    level: "Intermediário",
    description: "Organize escopo, quantitativos, custos, prazos, riscos e acompanhamento da obra.",
    contents: ["Escopo e estrutura do empreendimento", "Custos e orçamento", "Prazo e sequenciamento", "Controle integrado e comunicação", "Orçamento detalhado e incertezas", "Cronograma e recursos", "Medição, valor agregado e mudanças", "Estudos de caso e encerramento"],
    availability: "ebooks/planejamento-obras.pdf",
    coverImage: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=800&q=85",
    color: "#655345",
    pattern: "plan"
  },
  {
    id: "topografia-pratica",
    title: "Topografia: conceitos e levantamento",
    subject: "Topografia",
    author: "Biblioteca Engenharia Civil",
    level: "Básico",
    description: "Aprenda escalas, coordenadas, nivelamento, curvas de nível e documentação de levantamentos.",
    contents: ["Referência, escala e precisão", "Distâncias, ângulos e coordenadas", "Nivelamento geométrico", "Planta, relevo e entrega", "Instrumentos e caderno de campo", "GNSS, projeção e georreferenciamento", "Erros, ajustamento e controle", "Relevo, locação e volumes"],
    availability: "ebooks/topografia-pratica.pdf",
    coverImage: "https://images.unsplash.com/photo-1628158088936-68ccaaa400dc?auto=format&fit=crop&w=800&q=85",
    color: "#49614c",
    pattern: "contour"
  },
  {
    id: "estruturas-concreto-intro",
    title: "Estruturas de Concreto: visão geral",
    subject: "Estruturas de Concreto",
    author: "Biblioteca Engenharia Civil",
    level: "Avançado",
    description: "Estude concepção, ações, análise estrutural, estados limites e revisão responsável de projetos.",
    contents: ["Concepção e caminho das cargas", "Ações e análise estrutural", "Elementos, material e serviço", "Projeto, verificação e responsabilidade", "Lajes, vigas, pilares e caminho das cargas", "Serviço, fissuração e durabilidade", "Robustez e revisão independente", "Detalhamento, execução e qualidade"],
    availability: "ebooks/estruturas-concreto-intro.pdf",
    coverImage: "https://images.unsplash.com/photo-1569258592171-357ea26da4df?auto=format&fit=crop&w=800&q=85",
    color: "#66545d",
    pattern: "structure"
  },
  {
    id: "seguranca-canteiro",
    title: "Segurança do Trabalho no Canteiro",
    subject: "Segurança do Trabalho",
    author: "Biblioteca Engenharia Civil",
    level: "Básico",
    description: "Guia de prevenção com reconhecimento de perigos, controles, resposta a emergências e gestão.",
    contents: ["Perigo, risco e prevenção", "Planejamento e controles", "Organização do canteiro e tarefas críticas", "Emergência, aprendizado e gestão", "Trabalho em altura, andaimes e aberturas", "Escavações, máquinas e movimentação", "Eletricidade, incêndio e agentes ambientais", "Saúde ocupacional, emergência e aprendizagem"],
    availability: "ebooks/seguranca-canteiro.pdf",
    coverImage: "https://images.unsplash.com/photo-1567954970774-58d6aa6c50dc?auto=format&fit=crop&w=800&q=85",
    color: "#715e3c",
    pattern: "grid"
  }
];

const subjectIcons = ["∫", "⌁", "⌘", "▱", "◈", "▥", "⌂", "≈", "◉", "⌖", "◇", "▧", "◷", "＋", "＋"];
const coverPatterns = {
  structure: '<path d="M290 195V28l90-55 90 55v167M315 195V45l65-40 65 40v150M340 195V62l40-25 40 25v133M290 65h180M290 115h180M290 155h180M290 195h180" stroke="currentColor" stroke-width="2"/><circle cx="380" cy="112" r="95" stroke="currentColor" stroke-opacity=".4"/>',
  beam: '<path d="M245 42h230M245 62h230M275 62v138m50-138v138m50-138v138m50-138v138m50-138v138M245 200h230M245 195v10m230-10v10" stroke="currentColor" stroke-width="2"/><path d="M230 132h255M250 85h220M250 165h220" stroke="currentColor" stroke-dasharray="5 7"/>',
  soil: '<path d="M260 48h230M260 48v42h230V48M260 90v36h230V90M260 126v34h230v-34M260 160v42h230v-42" stroke="currentColor" stroke-width="2"/><path d="M260 69h230m-230 40h230m-230 67h230M290 90v36m38-36v36m75-36v36m42-36v36" stroke="currentColor" stroke-dasharray="4 7"/>',
  grid: '<path d="M280 30h180v180H280zM320 30v180m40-180v180m40-180v180M280 70h180m-180 40h180m-180 40h180" stroke="currentColor" stroke-width="1.5"/><path d="m300 195 140-150m-90 165 130-140" stroke="currentColor" stroke-opacity=".6"/>',
  water: '<path d="M255 60c40-35 78 35 118 0s78 35 118 0M255 95c40-35 78 35 118 0s78 35 118 0M255 130c40-35 78 35 118 0s78 35 118 0M255 165c40-35 78 35 118 0s78 35 118 0M255 200c40-35 78 35 118 0s78 35 118 0" stroke="currentColor" stroke-width="2"/>',
  plan: '<path d="M278 40h190v165H278zM300 65h62v50h-62zM382 65h65v20h-65zM382 95h65v20h-65zM300 130h147v55H300z" stroke="currentColor" stroke-width="2"/><path d="M310 140h125m-125 12h80m-80 12h110" stroke="currentColor" stroke-dasharray="5 6"/>',
  contour: '<path d="M257 64c34-32 58 20 94-2s63 16 91-6m-196 35c42-34 60 22 103-1s60 19 96-3m-198 34c42-34 60 22 103-1s60 19 96-3m-187 39c42-34 60 22 103-1s60 19 96-3m-180 42c42-34 60 22 103-1s60 19 96-3" stroke="currentColor" stroke-width="2"/>'
};

const subjectFilter = document.querySelector("#subject-filter");
const levelFilter = document.querySelector("#level-filter");
const searchInput = document.querySelector("#search-input");
const bookGrid = document.querySelector("#book-grid");
const resultsCount = document.querySelector("#results-count");
const emptyState = document.querySelector("#empty-state");
const homeView = document.querySelector("#home-view");
const detailView = document.querySelector("#detail-view");
const navMenu = document.querySelector("#primary-nav");
const menuToggle = document.querySelector(".menu-toggle");

function populateSubjects() {
  subjects.forEach((subject) => {
    const option = document.createElement("option");
    option.value = subject;
    option.textContent = subject;
    subjectFilter.append(option);
  });
}

function coverMarkup(book, compact = false) {
  const pattern = coverPatterns[book.pattern] || coverPatterns.grid;
  return `<div class="book-cover${compact ? " compact-cover" : ""}" style="--cover:${book.color}">
    ${book.coverImage ? `<img class="cover-image" src="${book.coverImage}" alt="">` : ""}
    <svg class="cover-linework" viewBox="0 0 520 220" preserveAspectRatio="xMidYMid slice" aria-hidden="true">${pattern}</svg>
    <span class="sample-tag">GUIA AUTORAL</span>
    <div class="cover-top"><span>ENGENHARIA CIVIL</span><span>EC. 0${books.indexOf(book) + 1}</span></div>
    <div class="cover-main">${book.title}</div>
    <div class="cover-bottom"><span>${book.subject.toUpperCase()}</span><span>MATERIAL DE ESTUDO</span></div>
  </div>`;
}

function bookCardMarkup(book) {
  return `<article class="book-card">
    <button class="book-card-button" type="button" data-book-id="${book.id}" aria-label="Ver detalhes de ${book.title}">
      ${coverMarkup(book)}
      <div class="book-card-body">
        <div class="book-meta"><span class="subject-pill">${book.subject}</span><span class="level-pill">${book.level}</span></div>
        <h3>${book.title}</h3>
        <p>${book.description}</p>
        <span class="book-card-link">Ver detalhes <span aria-hidden="true">→</span></span>
      </div>
    </button>
  </article>`;
}

function renderBooks() {
  const query = searchInput.value.trim().toLocaleLowerCase("pt-BR");
  const subject = subjectFilter.value;
  const level = levelFilter.value;
  const filtered = books.filter((book) => {
    const searchable = `${book.title} ${book.subject} ${book.description} ${book.author}`.toLocaleLowerCase("pt-BR");
    return (!query || searchable.includes(query)) &&
      (!subject || book.subject === subject) &&
      (!level || book.level === level);
  });
  bookGrid.innerHTML = filtered.map(bookCardMarkup).join("");
  resultsCount.textContent = `${filtered.length} ${filtered.length === 1 ? "material encontrado" : "materiais encontrados"}`;
  emptyState.hidden = filtered.length !== 0;
  bookGrid.hidden = filtered.length === 0;
}

function renderFeaturedSubjects() {
  const featured = ["Cálculo", "Resistência dos Materiais", "Mecânica dos Solos", "Estruturas de Concreto"];
  const container = document.querySelector("#featured-subjects");
  container.innerHTML = featured.map((subject) => {
    const index = subjects.indexOf(subject);
    const count = books.filter((book) => book.subject === subject).length;
    return `<button class="subject-card" type="button" data-subject="${subject}">
      <span class="subject-icon" aria-hidden="true">${subjectIcons[index]}</span>
      <strong>${subject}</strong><span class="subject-arrow" aria-hidden="true">↗</span>
      <span class="sr-only">${count} ${count === 1 ? "material" : "materiais"}; filtrar biblioteca</span>
    </button>`;
  }).join("");
}

function renderDetail(id) {
  const book = books.find((item) => item.id === id);
  if (!book) {
    detailView.innerHTML = `<button class="detail-back" type="button" data-back>← Voltar à biblioteca</button><div class="empty-state"><span aria-hidden="true">⌕</span><h3>Material não encontrado</h3><p>Este e-book não está disponível na biblioteca demonstrativa.</p><a class="button button-outline" href="#biblioteca">Voltar à biblioteca</a></div>`;
    return;
  }
  const contents = book.contents.map((item) => `<li>${item}</li>`).join("");
  const action = book.availability
    ? `<a class="button button-accent detail-action" href="${book.availability}" download>Baixar e-book (PDF) <span aria-hidden="true">↓</span></a>`
    : `<div class="coming-soon detail-action"><span aria-hidden="true">◷</span> Em breve — arquivo ainda não disponível</div>`;
  detailView.innerHTML = `<div class="breadcrumb"><a href="#inicio">Início</a><span aria-hidden="true">/</span><a href="#biblioteca">Biblioteca</a><span aria-hidden="true">/</span><span>${book.subject}</span></div>
    <button class="detail-back" type="button" data-back>← Voltar à biblioteca</button>
    <div class="detail-grid">
      <div class="detail-cover">${coverMarkup(book, true)}</div>
      <article class="detail-copy">
        <div class="book-meta"><span class="subject-pill">${book.subject}</span><span class="level-pill">${book.level}</span></div>
        <h1>${book.title}</h1>
        <p class="detail-author">Por ${book.author}</p>
        <p class="detail-description">${book.description}</p>
        ${action}
        <div class="detail-toc"><h2>Sumário</h2><ol>${contents}</ol></div>
        <p class="detail-note"><strong>Nota de estudo:</strong> este guia é material educacional original, para revisão e aprendizagem. Ele não substitui normas vigentes, projeto específico, inspeção local, formação profissional ou responsabilidade técnica.</p>
      </article>
    </div>`;
}

function updateRoute() {
  const route = window.location.hash.slice(1);
  const detailMatch = route.match(/^ebook\/(.+)$/);
  const isDetail = Boolean(detailMatch);
  homeView.hidden = isDetail;
  detailView.hidden = !isDetail;
  document.title = isDetail ? "Detalhes do e-book — Engenharia Civil" : "Engenharia Civil — sua biblioteca de estudos";
  if (detailMatch) {
    renderDetail(decodeURIComponent(detailMatch[1]));
    window.scrollTo(0, 0);
  }
  if (route === "biblioteca" && !isDetail) {
    window.setTimeout(() => document.querySelector("#biblioteca").scrollIntoView(), 0);
  }
  navMenu.classList.remove("is-open");
  menuToggle.setAttribute("aria-expanded", "false");
  menuToggle.setAttribute("aria-label", "Abrir menu");
}

populateSubjects();
renderFeaturedSubjects();
renderBooks();
document.querySelector("#current-year").textContent = new Date().getFullYear();

searchInput.addEventListener("input", renderBooks);
subjectFilter.addEventListener("change", renderBooks);
levelFilter.addEventListener("change", renderBooks);
document.querySelector("#clear-filters").addEventListener("click", () => {
  searchInput.value = "";
  subjectFilter.value = "";
  levelFilter.value = "";
  renderBooks();
});
document.querySelector("#empty-clear").addEventListener("click", () => {
  searchInput.value = "";
  subjectFilter.value = "";
  levelFilter.value = "";
  renderBooks();
  searchInput.focus();
});
document.addEventListener("click", (event) => {
  const bookButton = event.target.closest("[data-book-id]");
  const subjectButton = event.target.closest("[data-subject]");
  if (bookButton) {
    window.location.hash = `ebook/${encodeURIComponent(bookButton.dataset.bookId)}`;
  } else if (subjectButton) {
    subjectFilter.value = subjectButton.dataset.subject;
    renderBooks();
    window.location.hash = "biblioteca";
  } else if (event.target.closest("[data-back]")) {
    window.location.hash = "biblioteca";
  }
});
window.addEventListener("hashchange", updateRoute);
updateRoute();

menuToggle.addEventListener("click", () => {
  const isOpen = menuToggle.getAttribute("aria-expanded") === "true";
  menuToggle.setAttribute("aria-expanded", String(!isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Abrir menu" : "Fechar menu");
  navMenu.classList.toggle("is-open", !isOpen);
});
navMenu.addEventListener("click", (event) => {
  if (event.target.closest("a")) {
    navMenu.classList.remove("is-open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Abrir menu");
  }
});
document.addEventListener("keydown", (event) => {
  if (event.key === "/" && !["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName)) {
    event.preventDefault();
    searchInput.focus();
    window.location.hash = "biblioteca";
  }
  if (event.key === "Escape" && navMenu.classList.contains("is-open")) {
    navMenu.classList.remove("is-open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.focus();
  }
});

document.querySelector("#contact-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const formData = new FormData(form);
  const name = formData.get("name");
  const email = formData.get("email");
  const message = formData.get("message");
  const feedback = document.querySelector("#form-feedback");
  const subject = `Mensagem pelo site — ${name}`;
  const body = `Nome: ${name}\nE-mail para resposta: ${email}\n\nMensagem:\n${message}`;
  const mailto = `mailto:engenhariash52@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

  feedback.textContent = "Seu aplicativo de e-mail deve abrir com a mensagem pronta. Revise o conteúdo e envie por lá.";
  feedback.hidden = false;
  window.location.href = mailto;
});
